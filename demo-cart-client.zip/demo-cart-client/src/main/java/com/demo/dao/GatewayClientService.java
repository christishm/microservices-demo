package com.demo.dao;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient("DEMO-GATEWAY-ZUUL")
public interface GatewayClientService {
    
	@GetMapping("/get-logged-user")
	String getLoggedInUserName();
}
