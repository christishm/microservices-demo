package com.demo.service;

import com.demo.model.Price;

public interface PriceService {
	
	Price fetchPrice(long productId);

}
