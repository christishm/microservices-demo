package com.demo.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.jpa.PriceRestRepository;
import com.demo.model.Price;
import com.demo.service.PriceService;

@Service
public class PriceServiceImpl implements PriceService{
	
	@Autowired
	PriceRestRepository priceRepository;

	@Override
	public Price fetchPrice(long productId) {
		return priceRepository.findOne(productId);
	}

}
