package com.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Price {
	
	@Id
	private long priceId;
	
	private long productId;
	
	private double priceInfo;
	
	public Price() {
		super();
	}
	
	
	public Price(long priceId, long productId, double priceInfo) {
		super();
		this.priceId = priceId;
		this.productId = productId;
		this.priceInfo = priceInfo;
	}



	@Override
	public String toString() {
		return "Price [priceId=" + priceId + ", productId=" + productId + ", priceInfo=" + priceInfo + "]";
	}



	public long getPriceId() {
		return priceId;
	}

	public long getProductId() {
		return productId;
	}

	public double getPriceInfo() {
		return priceInfo;
	}

	public void setPriceId(long priceId) {
		this.priceId = priceId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public void setPriceInfo(double priceInfo) {
		this.priceInfo = priceInfo;
	}

}
