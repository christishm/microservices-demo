package com.demo.jpa;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.demo.model.Price;

@RepositoryRestResource(path="/")
public interface PriceRestRepository extends PagingAndSortingRepository<Price, Long>{

}
