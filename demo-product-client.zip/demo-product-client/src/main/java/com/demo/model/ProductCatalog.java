package com.demo.model;

import java.util.List;

import javax.persistence.Entity;

@Entity
public class ProductCatalog {
	
	public long getCatalogId() {
		return catalogId;
	}

	public String getCatalogName() {
		return catalogName;
	}

	public List<Category> getCategories() {
		return categories;
	}

	public void setCatalogId(long catalogId) {
		this.catalogId = catalogId;
	}

	public void setCatalogName(String catalogName) {
		this.catalogName = catalogName;
	}

	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}

	private long catalogId;
	
	private String catalogName;
	
	private List<Category> categories;
	
	public ProductCatalog() {
		super();
	}

}
