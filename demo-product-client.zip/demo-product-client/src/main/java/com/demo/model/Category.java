package com.demo.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Category {
	
	@Id
	private long categoryId;
	
	private String categoryName;
	
	@OneToMany(cascade=CascadeType.ALL)
    private List<Product> products;
    
    private long catalogId;
    
    
    public Category() {
    	super();
    }


	public long getCategoryId() {
		return categoryId;
	}


	public String getCategoryName() {
		return categoryName;
	}


	public List<Product> getProducts() {
		return products;
	}


	public long getCatalogId() {
		return catalogId;
	}


	public void setCategoryId(long categoryId) {
		this.categoryId = categoryId;
	}


	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}


	public void setProducts(List<Product> products) {
		this.products = products;
	}


	public void setCatalogId(long catalogId) {
		this.catalogId = catalogId;
	}

	

}
