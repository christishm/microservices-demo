package com.demo.jpa;

import org.springframework.data.repository.CrudRepository;

import com.demo.model.Category;


public interface CatagoryRepository extends CrudRepository<Category,Long>{

}
