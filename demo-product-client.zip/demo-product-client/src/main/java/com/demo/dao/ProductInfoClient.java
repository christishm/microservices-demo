package com.demo.dao;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.demo.model.Product;

@FeignClient("PRODUCT-INFO")
public interface ProductInfoClient {

	@GetMapping("/")
	List<Product> getProducts();
}
