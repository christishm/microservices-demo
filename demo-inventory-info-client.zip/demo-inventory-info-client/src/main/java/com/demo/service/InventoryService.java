package com.demo.service;

import com.demo.model.InventoryInfo;

public interface InventoryService {
	
	InventoryInfo findInventoryInfo(String productId);
}	
	
