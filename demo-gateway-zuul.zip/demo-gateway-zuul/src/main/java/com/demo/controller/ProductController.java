package com.demo.controller;


import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {
	
	private static final Logger userlogger = Logger.getLogger(ProductController.class);
	
	@GetMapping("/")
	@ResponseBody
	public String onLogin(){
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if(null != authentication) {
			Object principal = SecurityContextHolder.getContext()
					.getAuthentication().getPrincipal();
			userlogger.info("Logged In User is :"+((UserDetails) principal).getUsername());
		}
		return "Login Success";
	}

}
