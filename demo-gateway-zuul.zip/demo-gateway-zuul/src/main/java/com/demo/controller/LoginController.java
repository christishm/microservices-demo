package com.demo.controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {
	
	public static Logger log = LoggerFactory.getLogger(LoginController.class);
	
	@GetMapping("/")
	public String onLogin(){
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if(null != authentication) {
			Object principal = SecurityContextHolder.getContext()
					.getAuthentication().getPrincipal();
			log.info("Logged In User is :"+((UserDetails) principal).getUsername());
		}
		return "product";
	}

}
