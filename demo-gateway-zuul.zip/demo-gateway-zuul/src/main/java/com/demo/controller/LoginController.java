package com.demo.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

import com.demo.service.CartClientApiService;

@Controller
public class LoginController {
	
	@Autowired
	CartClientApiService cartClientApiService;
	
	@GetMapping("/")
	public String onLogin(){
		
		return "product";
	}
	
	@GetMapping("/cart/{productId}")
    public String onClickAddToCart(@PathVariable String productId) {
		String userId = cartClientApiService.getLogInIdForUser();
    	if(StringUtils.isEmpty(userId)) {
    		throw new RuntimeException("User not Logged in...");
    	}
    	ResponseEntity<Void> response= cartClientApiService.addToCart(userId,productId);
    	System.out.println("Status.........................."+response.getStatusCodeValue());
    	return "cart";
    }
	
	//This service wiil be used by other clients for getting LoggedIn User name
	@GetMapping("/get-logged-user")
	public String getLoggedInUserName() {
		String userId = cartClientApiService.getLogInIdForUser();
		return userId;
	}
	
}
