package com.demo.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import com.demo.dao.CartClientService;
import com.demo.service.CartClientApiService;

@Service
public class CartClientApiServiceImpl implements CartClientApiService{
	
	public static Logger log = LoggerFactory.getLogger(CartClientApiServiceImpl.class);

	@Autowired
	CartClientService cartClientService;
	
	@Override
	public ResponseEntity<Void> addToCart(String userId,String productId) {
		return cartClientService.addToCart(userId,productId);
	}
	
	public String getLogInIdForUser() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if(null != authentication) {
			Object principal = SecurityContextHolder.getContext()
					.getAuthentication().getPrincipal();
			log.info("Logged In User is :"+((UserDetails) principal).getUsername());
			return ((UserDetails) principal).getUsername();
		}
		return null;
	}

}
