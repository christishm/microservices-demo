package com.demo.service;

import org.springframework.http.ResponseEntity;

public interface CartClientApiService {
	
	ResponseEntity<Void> addToCart(String userId,String productId);
	
	String getLogInIdForUser();
	
}
