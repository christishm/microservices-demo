package com.demo.service;

import org.springframework.http.ResponseEntity;

public interface CartClientApiService {
	
	ResponseEntity<String> addToCart(String productId);
	
	String getLogInIdForUser();
	
}
